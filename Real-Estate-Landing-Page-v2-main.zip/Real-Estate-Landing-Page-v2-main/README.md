# Real-Estate-Landing-Page-v2
Convert Figma Design to HTML page https://www.figma.com/community/file/968241156604846869
# Live Preview
https://themes12.github.io/Real-Estate-Landing-Page-v2/
# Donate
USDT/BUSD (bep-20 or binanace smart chain) : 0xBC04087D923b444f17E0C976B51Ba6Ac26A3D050<br>
Doge : D6T5Vz4Ltfq4G2odp4BGfq6VBwCVRConDW<br>
BTC : bc1qzk09ga9x39xf9qzvx6frtq6qalg20e83xem6zk<br>
